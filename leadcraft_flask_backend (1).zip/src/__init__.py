import sys
import os
# sys.path.insert(0, os.path.dirname(os.path.dirname(__file__))) # No longer needed with package structure

from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_cors import CORS
from flask_login import LoginManager
from dotenv import load_dotenv

# Carregar variáveis de ambiente (Opcional: load_dotenv() é mais para desenvolvimento local)
# A plataforma de implantação geralmente injeta variáveis de ambiente diretamente.
# load_dotenv(os.path.join(project_root, ".env"))

# Inicializar extensões (globally, but uninitialized)
db = SQLAlchemy()
migrate = Migrate()
login_manager = LoginManager()

def create_app(config_name="default"):
    # Use app context for path finding relative to instance folder if needed
    app = Flask(__name__, instance_relative_config=False, static_folder="static", static_url_path="")

    # Configuração da aplicação
    app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "dev-secret-key")
    app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv("DATABASE_URL")
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

    # Inicializar extensões com a app
    db.init_app(app)
    migrate.init_app(app, db)
    CORS(app, supports_credentials=True) # Permitir CORS para o frontend React
    login_manager.init_app(app)

    # Configurar Flask-Login
    login_manager.login_view = "auth.login" # Define the login view endpoint
    login_manager.login_message = "Por favor, faça login para acessar esta página."
    login_manager.login_message_category = "info"

    with app.app_context():
        # Importar modelos aqui para que o Flask-Migrate os reconheça
        # e para garantir que db está inicializado antes de serem usados
        from .models.user import User
        from .models.pipeline_stage import PipelineStage
        from .models.lead import Lead
        from .models.custom_field import CustomFieldDefinition, CustomFieldValue
        from .models.user_plan import UserPlan
        from .models.api_key import ApiKey

        # Importar e registrar Blueprints (rotas)
        from .routes.auth import auth_bp
        from .routes.leads import leads_bp
        from .routes.pipelines import pipelines_bp
        from .routes.custom_fields import custom_fields_bp
        from .routes.api_keys import api_keys_bp
        from .routes.reports import reports_bp
        # from .routes.plans import plans_bp # Plans blueprint not implemented yet

        app.register_blueprint(auth_bp, url_prefix="/api/auth")
        app.register_blueprint(leads_bp, url_prefix="/api/leads")
        app.register_blueprint(pipelines_bp, url_prefix="/api/pipelines")
        app.register_blueprint(custom_fields_bp, url_prefix="/api/custom-fields")
        app.register_blueprint(api_keys_bp, url_prefix="/api/api-keys")
        app.register_blueprint(reports_bp, url_prefix="/api/reports")
        # app.register_blueprint(plans_bp, url_prefix="/api/plans")

        @login_manager.user_loader
        def load_user(user_id):
            # Return the user object from the user ID stored in the session
            return User.query.get(int(user_id))

        # Rota de teste inicial
        @app.route("/api/hello")
        def hello():
            return {"message": "Hello from LeadCraft Flask API!"}

        # Optional: Create database tables if they don\'t exist
        # db.create_all() # Usually handled by migrations (flask db upgrade)

    return app

