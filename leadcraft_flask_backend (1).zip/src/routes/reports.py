from flask import Blueprint, jsonify
from flask_login import login_required, current_user
from src import db
from src.models.lead import Lead
from src.models.pipeline_stage import PipelineStage
from sqlalchemy import func, case
from datetime import datetime, timedelta

reports_bp = Blueprint("reports", __name__)

# Report: Lead count by stage
@reports_bp.route("/summary/by_stage", methods=["GET"])
@login_required
def report_by_stage():
    # Get all stages defined by the user to ensure all are included, even if empty
    user_stages = PipelineStage.query.filter_by(user_id=current_user.id).order_by(PipelineStage.stage_order).all()
    stage_map = {stage.id: {"name": stage.name, "count": 0} for stage in user_stages}

    # Query lead counts grouped by stage
    results = db.session.query(
        Lead.pipeline_stage_id,
        func.count(Lead.id)
    ).filter(
        Lead.user_id == current_user.id,
        Lead.pipeline_stage_id.isnot(None) # Exclude leads with no stage (shouldn't happen often)
    ).group_by(Lead.pipeline_stage_id).all()

    total_leads = 0
    for stage_id, count in results:
        if stage_id in stage_map:
            stage_map[stage_id]["count"] = count
            total_leads += count

    # Prepare ordered list based on user_stages
    summary_list = [stage_map[stage.id] for stage in user_stages]

    return jsonify({
        "total_leads": total_leads,
        "by_stage": summary_list
    })

# Report: Lead value by stage (Example)
@reports_bp.route("/summary/value_by_stage", methods=["GET"])
@login_required
def report_value_by_stage():
    # Get all stages defined by the user
    user_stages = PipelineStage.query.filter_by(user_id=current_user.id).order_by(PipelineStage.stage_order).all()
    stage_map = {stage.id: {"name": stage.name, "total_value": 0.0} for stage in user_stages}

    # Query lead values grouped by stage
    results = db.session.query(
        Lead.pipeline_stage_id,
        func.sum(Lead.lead_value)
    ).filter(
        Lead.user_id == current_user.id,
        Lead.pipeline_stage_id.isnot(None),
        Lead.lead_value.isnot(None)
    ).group_by(Lead.pipeline_stage_id).all()

    total_value = 0.0
    for stage_id, value in results:
        if stage_id in stage_map and value is not None:
            stage_map[stage_id]["total_value"] = float(value)
            total_value += float(value)

    # Prepare ordered list
    summary_list = [stage_map[stage.id] for stage in user_stages]

    return jsonify({
        "total_value": total_value,
        "by_stage": summary_list
    })

# Report: Leads created over time (e.g., last 30 days)
@reports_bp.route("/summary/created_over_time", methods=["GET"])
@login_required
def report_created_over_time():
    days_param = request.args.get("days", 30, type=int)
    end_date = datetime.utcnow().date() + timedelta(days=1) # Include today
    start_date = end_date - timedelta(days=days_param)

    # Query leads created within the date range, grouped by date
    results = db.session.query(
        func.date(Lead.created_at).label("creation_date"),
        func.count(Lead.id).label("count")
    ).filter(
        Lead.user_id == current_user.id,
        Lead.created_at >= start_date,
        Lead.created_at < end_date
    ).group_by(func.date(Lead.created_at)).order_by(func.date(Lead.created_at)).all()

    # Create a dictionary with all dates in the range initialized to 0
    date_counts = { (start_date + timedelta(days=i)).isoformat(): 0 for i in range(days_param) }

    # Fill in counts from the query results
    for row in results:
        date_str = row.creation_date.isoformat()
        date_counts[date_str] = row.count
        
    # Convert to list format expected by charts (e.g., [{date: 'YYYY-MM-DD', count: N}])
    summary_list = [{"date": date_str, "count": count} for date_str, count in date_counts.items()]
    # Ensure the list is sorted by date
    summary_list.sort(key=lambda x: x["date"])

    return jsonify(summary_list)

# Placeholder for other potential reports
# - Conversion rates between stages
# - Average time spent in each stage
# - Lead source analysis (if source field is added)

