from flask import Blueprint, request, jsonify
from flask_login import login_required, current_user
from src import db
from src.models.lead import Lead
from src.models.pipeline_stage import PipelineStage
from src.models.custom_field import CustomFieldDefinition, CustomFieldValue
from src.models.user import User # To check plan limits
from sqlalchemy.orm import joinedload

leads_bp = Blueprint("leads", __name__)

# Helper function to get plan limits
def get_plan_limit(plan: str) -> int:
    if plan == "advanced":
        return 999
    if plan == "pro":
        return 300
    return 10 # free plan

# Get all leads for the current user, potentially filtered by stage
@leads_bp.route("", methods=["GET"])
@login_required
def get_leads():
    # Eager load related data to avoid N+1 queries
    query = Lead.query.filter_by(user_id=current_user.id).options(
        joinedload(Lead.pipeline_stage),
        joinedload(Lead.custom_field_values).joinedload(CustomFieldValue.definition)
    ).order_by(Lead.created_at.desc())

    # Optional filtering by stage_id can be added here if needed
    # stage_id = request.args.get("stage_id")
    # if stage_id:
    #     query = query.filter_by(pipeline_stage_id=stage_id)

    leads = query.all()

    leads_data = []
    for lead in leads:
        custom_fields = {
            cfv.definition.field_name: cfv.field_value
            for cfv in lead.custom_field_values
        }
        leads_data.append({
            "id": lead.id,
            "name": lead.name,
            "email": lead.email,
            "phone": lead.phone,
            "notes": lead.notes,
            "lead_value": float(lead.lead_value) if lead.lead_value is not None else None,
            "pipeline_stage_id": lead.pipeline_stage_id,
            "pipeline_stage_name": lead.pipeline_stage.name if lead.pipeline_stage else None,
            "created_at": lead.created_at.isoformat(),
            "updated_at": lead.updated_at.isoformat(),
            "custom_fields": custom_fields
        })

    return jsonify(leads_data)

# Get a specific lead by ID
@leads_bp.route("/<int:lead_id>", methods=["GET"])
@login_required
def get_lead(lead_id):
    lead = Lead.query.filter_by(id=lead_id, user_id=current_user.id).options(
        joinedload(Lead.pipeline_stage),
        joinedload(Lead.custom_field_values).joinedload(CustomFieldValue.definition)
    ).first()

    if not lead:
        return jsonify({"message": "Lead não encontrado"}), 404

    custom_fields = {
        cfv.definition.field_name: cfv.field_value
        for cfv in lead.custom_field_values
    }

    return jsonify({
        "id": lead.id,
        "name": lead.name,
        "email": lead.email,
        "phone": lead.phone,
        "notes": lead.notes,
        "lead_value": float(lead.lead_value) if lead.lead_value is not None else None,
        "pipeline_stage_id": lead.pipeline_stage_id,
        "pipeline_stage_name": lead.pipeline_stage.name if lead.pipeline_stage else None,
        "created_at": lead.created_at.isoformat(),
        "updated_at": lead.updated_at.isoformat(),
        "custom_fields": custom_fields
    })

# Create a new lead
@leads_bp.route("", methods=["POST"])
@login_required
def create_lead():
    # Check plan limits
    lead_count = Lead.query.filter_by(user_id=current_user.id).count()
    limit = get_plan_limit(current_user.plan)
    if lead_count >= limit:
        return jsonify({
            "message": f"Limite de {limit} leads atingido para o plano {current_user.plan}."
        }), 403

    data = request.get_json()
    if not data or not data.get("name"):
        return jsonify({"message": "Nome do lead é obrigatório"}), 400

    # Find the first pipeline stage for the user (default stage)
    default_stage = PipelineStage.query.filter_by(user_id=current_user.id).order_by(PipelineStage.stage_order).first()
    if not default_stage:
         # This should ideally not happen if default stages are created on registration
         return jsonify({"message": "Nenhuma etapa de funil encontrada. Crie uma etapa primeiro."}), 400

    new_lead = Lead(
        user_id=current_user.id,
        name=data["name"],
        email=data.get("email"),
        phone=data.get("phone"),
        notes=data.get("notes"),
        lead_value=data.get("lead_value"),
        pipeline_stage_id=data.get("pipeline_stage_id", default_stage.id) # Default to first stage if not provided
    )

    # Handle custom fields
    custom_fields_data = data.get("custom_fields", {})
    custom_field_values_to_add = []
    if custom_fields_data:
        definitions = CustomFieldDefinition.query.filter(
            CustomFieldDefinition.user_id == current_user.id,
            CustomFieldDefinition.field_name.in_(custom_fields_data.keys())
        ).all()
        
        definitions_map = {d.field_name: d for d in definitions}

        for field_name, field_value in custom_fields_data.items():
            definition = definitions_map.get(field_name)
            if definition:
                # Basic type validation could be added here based on definition.field_type
                cfv = CustomFieldValue(
                    lead=new_lead, # Associate with the lead being created
                    custom_field_definition_id=definition.id,
                    field_value=str(field_value) # Store as string
                )
                custom_field_values_to_add.append(cfv)

    try:
        db.session.add(new_lead)
        if custom_field_values_to_add:
            db.session.add_all(custom_field_values_to_add)
        db.session.commit()
        
        # Fetch the created lead with relations for the response
        created_lead = get_lead(new_lead.id).get_json()
        return jsonify(created_lead), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Erro ao criar lead", "error": str(e)}), 500

# Update an existing lead
@leads_bp.route("/<int:lead_id>", methods=["PUT"])
@login_required
def update_lead(lead_id):
    lead = Lead.query.filter_by(id=lead_id, user_id=current_user.id).options(
        joinedload(Lead.custom_field_values).joinedload(CustomFieldValue.definition)
    ).first()

    if not lead:
        return jsonify({"message": "Lead não encontrado"}), 404

    data = request.get_json()
    if not data:
        return jsonify({"message": "Nenhum dado fornecido para atualização"}), 400

    updated = False

    # Update standard fields
    for field in ["name", "email", "phone", "notes", "lead_value", "pipeline_stage_id"]:
        if field in data and getattr(lead, field) != data[field]:
            # Special check for pipeline_stage_id to ensure it belongs to the user
            if field == "pipeline_stage_id":
                stage = PipelineStage.query.filter_by(id=data[field], user_id=current_user.id).first()
                if not stage:
                    return jsonify({"message": f"Etapa de funil com ID {data[field]} inválida ou não pertence a você."}), 400
            setattr(lead, field, data[field])
            updated = True

    # Update custom fields
    custom_fields_data = data.get("custom_fields", {})
    if custom_fields_data:
        definitions = CustomFieldDefinition.query.filter(
            CustomFieldDefinition.user_id == current_user.id,
            CustomFieldDefinition.field_name.in_(custom_fields_data.keys())
        ).all()
        definitions_map = {d.field_name: d for d in definitions}
        
        existing_values_map = {cfv.definition.field_name: cfv for cfv in lead.custom_field_values}

        for field_name, field_value in custom_fields_data.items():
            definition = definitions_map.get(field_name)
            if definition:
                existing_cfv = existing_values_map.get(field_name)
                new_value_str = str(field_value) if field_value is not None else None
                
                if existing_cfv:
                    if existing_cfv.field_value != new_value_str:
                        existing_cfv.field_value = new_value_str
                        updated = True
                elif new_value_str is not None: # Only add if there is a value
                    new_cfv = CustomFieldValue(
                        lead_id=lead.id,
                        custom_field_definition_id=definition.id,
                        field_value=new_value_str
                    )
                    db.session.add(new_cfv)
                    updated = True

    if updated:
        try:
            db.session.commit()
            # Fetch the updated lead with relations for the response
            updated_lead = get_lead(lead.id).get_json()
            return jsonify(updated_lead)
        except Exception as e:
            db.session.rollback()
            return jsonify({"message": "Erro ao atualizar lead", "error": str(e)}), 500
    else:
        return jsonify({"message": "Nenhuma alteração fornecida"}), 400

# Delete a lead
@leads_bp.route("/<int:lead_id>", methods=["DELETE"])
@login_required
def delete_lead(lead_id):
    lead = Lead.query.filter_by(id=lead_id, user_id=current_user.id).first()
    if not lead:
        return jsonify({"message": "Lead não encontrado"}), 404

    try:
        # Custom field values will be deleted by cascade
        db.session.delete(lead)
        db.session.commit()
        return jsonify({"message": "Lead excluído com sucesso"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Erro ao excluir lead", "error": str(e)}), 500

