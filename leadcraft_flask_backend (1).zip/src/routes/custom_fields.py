from flask import Blueprint, request, jsonify
from flask_login import login_required, current_user
from src import db
from src.models.custom_field import CustomFieldDefinition

custom_fields_bp = Blueprint("custom_fields", __name__)

# Get all custom field definitions for the current user
@custom_fields_bp.route("/definitions", methods=["GET"])
@login_required
def get_custom_field_definitions():
    definitions = CustomFieldDefinition.query.filter_by(user_id=current_user.id).order_by(CustomFieldDefinition.created_at).all()
    return jsonify([{
        "id": definition.id,
        "field_name": definition.field_name,
        "field_type": definition.field_type,
        "options": definition.options # For select type
    } for definition in definitions])

# Create a new custom field definition
@custom_fields_bp.route("/definitions", methods=["POST"])
@login_required
def create_custom_field_definition():
    data = request.get_json()
    if not data or not data.get("field_name") or not data.get("field_type"):
        return jsonify({"message": "Nome do campo e tipo são obrigatórios"}), 400

    field_type = data["field_type"]
    # Basic validation for field type
    allowed_types = ["text", "number", "date", "select"]
    if field_type not in allowed_types:
        return jsonify({"message": f"Tipo de campo inválido. Permitidos: {', '.join(allowed_types)}"}), 400

    if field_type == "select" and not data.get("options"):
        return jsonify({"message": "Opções são obrigatórias para o tipo select"}), 400

    new_definition = CustomFieldDefinition(
        user_id=current_user.id,
        field_name=data["field_name"],
        field_type=field_type,
        options=data.get("options") if field_type == "select" else None
    )

    try:
        db.session.add(new_definition)
        db.session.commit()
        return jsonify({
            "id": new_definition.id,
            "field_name": new_definition.field_name,
            "field_type": new_definition.field_type,
            "options": new_definition.options
        }), 201
    except Exception as e:
        db.session.rollback()
        if "_user_field_name_uc" in str(e):
             return jsonify({"message": "Já existe um campo personalizado com este nome."}), 409
        return jsonify({"message": "Erro ao criar campo personalizado", "error": str(e)}), 500

# Update a custom field definition (only specific fields might be updatable, e.g., options for select)
@custom_fields_bp.route("/definitions/<int:definition_id>", methods=["PUT"])
@login_required
def update_custom_field_definition(definition_id):
    definition = CustomFieldDefinition.query.filter_by(id=definition_id, user_id=current_user.id).first()
    if not definition:
        return jsonify({"message": "Definição de campo personalizado não encontrada"}), 404

    data = request.get_json()
    updated = False

    # Example: Allow updating options for select type
    if definition.field_type == "select" and data.get("options") is not None and data["options"] != definition.options:
        definition.options = data["options"]
        updated = True
        
    # Usually, field_name and field_type are not changed after creation to avoid data inconsistency.
    # If name change is needed, consider implications on existing data/reports.

    if updated:
        try:
            db.session.commit()
            return jsonify({
                "id": definition.id,
                "field_name": definition.field_name,
                "field_type": definition.field_type,
                "options": definition.options
            })
        except Exception as e:
            db.session.rollback()
            return jsonify({"message": "Erro ao atualizar campo personalizado", "error": str(e)}), 500
    else:
        return jsonify({"message": "Nenhuma alteração válida fornecida ou permitida"}), 400

# Delete a custom field definition
@custom_fields_bp.route("/definitions/<int:definition_id>", methods=["DELETE"])
@login_required
def delete_custom_field_definition(definition_id):
    definition = CustomFieldDefinition.query.filter_by(id=definition_id, user_id=current_user.id).first()
    if not definition:
        return jsonify({"message": "Definição de campo personalizado não encontrada"}), 404

    # Deleting a definition will also delete all associated values due to cascade delete in the model.
    try:
        db.session.delete(definition)
        db.session.commit()
        return jsonify({"message": "Campo personalizado excluído com sucesso"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Erro ao excluir campo personalizado", "error": str(e)}), 500

