from flask import Blueprint, request, jsonify
from flask_login import login_required, current_user
from src import db
from src.models.api_key import ApiKey

api_keys_bp = Blueprint("api_keys", __name__)

# Get all API keys for the current user
@api_keys_bp.route("", methods=["GET"])
@login_required
def get_api_keys():
    # Check if user plan allows API access (e.g., only pro/advanced)
    if current_user.plan == "free":
        return jsonify({"message": "API Keys não estão disponíveis no plano gratuito."}), 403
        
    keys = ApiKey.query.filter_by(user_id=current_user.id).order_by(ApiKey.created_at.desc()).all()
    return jsonify([{
        "id": key.id,
        "key_preview": key.key[:8] + "..." + key.key[-4:], # Show only a preview
        "description": key.description,
        "is_active": key.is_active,
        "created_at": key.created_at.isoformat()
    } for key in keys])

# Create a new API key
@api_keys_bp.route("", methods=["POST"])
@login_required
def create_api_key():
    # Check plan limits or feature availability
    if current_user.plan == "free":
        return jsonify({"message": "API Keys não estão disponíveis no plano gratuito."}), 403
        
    # Optional: Limit the number of keys per user based on plan

    data = request.get_json()
    description = data.get("description")

    new_key = ApiKey(user_id=current_user.id, description=description)

    try:
        db.session.add(new_key)
        db.session.commit()
        # Return the full key only upon creation
        return jsonify({
            "id": new_key.id,
            "key": new_key.key, # Important: Show full key only once
            "description": new_key.description,
            "is_active": new_key.is_active,
            "created_at": new_key.created_at.isoformat()
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Erro ao criar chave de API", "error": str(e)}), 500

# Update an API key (e.g., description or active status)
@api_keys_bp.route("/<int:key_id>", methods=["PUT"])
@login_required
def update_api_key(key_id):
    if current_user.plan == "free":
        return jsonify({"message": "API Keys não estão disponíveis no plano gratuito."}), 403
        
    key = ApiKey.query.filter_by(id=key_id, user_id=current_user.id).first()
    if not key:
        return jsonify({"message": "Chave de API não encontrada"}), 404

    data = request.get_json()
    updated = False

    if data.get("description") is not None and data["description"] != key.description:
        key.description = data["description"]
        updated = True
    
    if data.get("is_active") is not None and data["is_active"] != key.is_active:
        key.is_active = data["is_active"]
        updated = True

    if updated:
        try:
            db.session.commit()
            return jsonify({
                "id": key.id,
                "key_preview": key.key[:8] + "..." + key.key[-4:],
                "description": key.description,
                "is_active": key.is_active,
                "created_at": key.created_at.isoformat()
            })
        except Exception as e:
            db.session.rollback()
            return jsonify({"message": "Erro ao atualizar chave de API", "error": str(e)}), 500
    else:
        return jsonify({"message": "Nenhuma alteração fornecida"}), 400

# Delete an API key
@api_keys_bp.route("/<int:key_id>", methods=["DELETE"])
@login_required
def delete_api_key(key_id):
    if current_user.plan == "free":
        return jsonify({"message": "API Keys não estão disponíveis no plano gratuito."}), 403
        
    key = ApiKey.query.filter_by(id=key_id, user_id=current_user.id).first()
    if not key:
        return jsonify({"message": "Chave de API não encontrada"}), 404

    try:
        db.session.delete(key)
        db.session.commit()
        return jsonify({"message": "Chave de API excluída com sucesso"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Erro ao excluir chave de API", "error": str(e)}), 500

# Endpoint for external lead capture using API Key
@api_keys_bp.route("/capture", methods=["POST"])
def capture_lead_external():
    api_key_header = request.headers.get("X-API-Key")
    if not api_key_header:
        return jsonify({"message": "Chave de API ausente no cabeçalho X-API-Key"}), 401

    api_key = ApiKey.query.filter_by(key=api_key_header, is_active=True).first()
    if not api_key:
        return jsonify({"message": "Chave de API inválida ou inativa"}), 403

    user = api_key.owner # Get the user associated with the API key

    # Check plan limits for the user
    lead_count = Lead.query.filter_by(user_id=user.id).count()
    limit = get_plan_limit(user.plan)
    if lead_count >= limit:
        # Even if the key is valid, the user's limit is reached
        return jsonify({
            "message": f"Limite de {limit} leads atingido para a conta associada a esta chave."
        }), 429 # Too Many Requests

    data = request.get_json()
    if not data or not data.get("name"):
        return jsonify({"message": "Nome do lead é obrigatório"}), 400

    # Find the first pipeline stage for the user (default stage)
    default_stage = PipelineStage.query.filter_by(user_id=user.id).order_by(PipelineStage.stage_order).first()
    if not default_stage:
         return jsonify({"message": "Erro interno: Nenhuma etapa de funil encontrada para o usuário."}), 500

    new_lead = Lead(
        user_id=user.id,
        name=data["name"],
        email=data.get("email"),
        phone=data.get("phone"),
        notes=data.get("notes", "Lead capturado via API"),
        lead_value=data.get("lead_value"),
        pipeline_stage_id=default_stage.id # Assign to the first stage
    )
    
    # Handle custom fields if provided
    custom_fields_data = data.get("custom_fields", {})
    custom_field_values_to_add = []
    if custom_fields_data:
        definitions = CustomFieldDefinition.query.filter(
            CustomFieldDefinition.user_id == user.id,
            CustomFieldDefinition.field_name.in_(custom_fields_data.keys())
        ).all()
        definitions_map = {d.field_name: d for d in definitions}

        for field_name, field_value in custom_fields_data.items():
            definition = definitions_map.get(field_name)
            if definition:
                cfv = CustomFieldValue(
                    lead=new_lead,
                    custom_field_definition_id=definition.id,
                    field_value=str(field_value)
                )
                custom_field_values_to_add.append(cfv)

    try:
        db.session.add(new_lead)
        if custom_field_values_to_add:
            db.session.add_all(custom_field_values_to_add)
        db.session.commit()
        return jsonify({"message": "Lead capturado com sucesso", "lead_id": new_lead.id}), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Erro ao capturar lead", "error": str(e)}), 500

# Need to import these for the capture endpoint
from src.models.lead import Lead
from src.models.pipeline_stage import PipelineStage
from src.models.custom_field import CustomFieldDefinition, CustomFieldValue
from src.routes.leads import get_plan_limit # Reuse helper function

