from flask import Blueprint, request, jsonify
from flask_login import login_user, logout_user, login_required, current_user
from src import db
from src.models.user import User
from src.models.pipeline_stage import PipelineStage # Import for default stages

auth_bp = Blueprint("auth", __name__)

# User Registration
@auth_bp.route("/register", methods=["POST"])
def register():
    data = request.get_json()
    if not data or not data.get("email") or not data.get("password") or not data.get("name"):
        return jsonify({"message": "Nome, email e senha são obrigatórios"}), 400

    if User.query.filter_by(email=data["email"]).first():
        return jsonify({"message": "Email já registrado"}), 409

    new_user = User(
        email=data["email"],
        name=data["name"]
    )
    new_user.set_password(data["password"])

    try:
        db.session.add(new_user)
        db.session.flush() # Get the new_user.id before commit

        # Create default pipeline stages for the new user
        default_stages = [
            {"name": "Novos Leads", "order": 1},
            {"name": "Contato Inicial", "order": 2},
            {"name": "Proposta Enviada", "order": 3},
            {"name": "Negociação", "order": 4},
            {"name": "Ganhos", "order": 5},
            {"name": "Perdidos", "order": 6}
        ]
        for stage_data in default_stages:
            stage = PipelineStage(user_id=new_user.id, name=stage_data["name"], stage_order=stage_data["order"])
            db.session.add(stage)

        db.session.commit()
        
        # Log the user in immediately after registration
        login_user(new_user)
        
        return jsonify({
            "id": new_user.id,
            "email": new_user.email,
            "name": new_user.name,
            "plan": new_user.plan
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Erro ao registrar usuário", "error": str(e)}), 500

# User Login
@auth_bp.route("/login", methods=["POST"])
def login():
    data = request.get_json()
    if not data or not data.get("email") or not data.get("password"):
        return jsonify({"message": "Email e senha são obrigatórios"}), 400

    user = User.query.filter_by(email=data["email"]).first()

    if not user or not user.check_password(data["password"]):
        return jsonify({"message": "Credenciais inválidas"}), 401

    login_user(user) # Manages session
    return jsonify({
        "id": user.id,
        "email": user.email,
        "name": user.name,
        "plan": user.plan
    })

# User Logout
@auth_bp.route("/logout", methods=["POST"])
@login_required
def logout():
    logout_user()
    return jsonify({"message": "Logout bem-sucedido"})

# Get Current User Info
@auth_bp.route("/me", methods=["GET"])
@login_required
def get_current_user():
    return jsonify({
        "id": current_user.id,
        "email": current_user.email,
        "name": current_user.name,
        "plan": current_user.plan
    })

# Update User Info (e.g., name)
@auth_bp.route("/me", methods=["PUT"])
@login_required
def update_user_info():
    data = request.get_json()
    updated = False

    if data.get("name") and data["name"] != current_user.name:
        current_user.name = data["name"]
        updated = True
    
    # Add other updatable fields here if needed

    if updated:
        try:
            db.session.commit()
            return jsonify({
                "id": current_user.id,
                "email": current_user.email,
                "name": current_user.name,
                "plan": current_user.plan
            })
        except Exception as e:
            db.session.rollback()
            return jsonify({"message": "Erro ao atualizar informações do usuário", "error": str(e)}), 500
    else:
        return jsonify({"message": "Nenhuma alteração fornecida"}), 400

# Update User Password
@auth_bp.route("/me/password", methods=["PUT"])
@login_required
def update_password():
    data = request.get_json()
    if not data or not data.get("currentPassword") or not data.get("newPassword"):
        return jsonify({"message": "Senha atual e nova senha são obrigatórias"}), 400

    if not current_user.check_password(data["currentPassword"]):
        return jsonify({"message": "Senha atual incorreta"}), 403

    current_user.set_password(data["newPassword"])
    try:
        db.session.commit()
        return jsonify({"message": "Senha atualizada com sucesso"})
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Erro ao atualizar senha", "error": str(e)}), 500

