from flask import Blueprint, request, jsonify
from flask_login import login_required, current_user
from src import db
from src.models.pipeline_stage import PipelineStage
from sqlalchemy import func

pipelines_bp = Blueprint("pipelines", __name__)

# Get all pipeline stages for the current user, ordered
@pipelines_bp.route("/stages", methods=["GET"])
@login_required
def get_pipeline_stages():
    stages = PipelineStage.query.filter_by(user_id=current_user.id).order_by(PipelineStage.stage_order).all()
    return jsonify([{
        "id": stage.id,
        "name": stage.name,
        "order": stage.stage_order
    } for stage in stages])

# Create a new pipeline stage
@pipelines_bp.route("/stages", methods=["POST"])
@login_required
def create_pipeline_stage():
    data = request.get_json()
    if not data or not data.get("name"):
        return jsonify({"message": "Nome da etapa é obrigatório"}), 400

    # Determine the order for the new stage (append to the end)
    max_order = db.session.query(func.max(PipelineStage.stage_order)).filter_by(user_id=current_user.id).scalar()
    new_order = (max_order or 0) + 1

    new_stage = PipelineStage(
        user_id=current_user.id,
        name=data["name"],
        stage_order=new_order
    )

    try:
        db.session.add(new_stage)
        db.session.commit()
        return jsonify({
            "id": new_stage.id,
            "name": new_stage.name,
            "order": new_stage.stage_order
        }), 201
    except Exception as e:
        db.session.rollback()
        # Check for unique constraint violation
        if "_user_stage_name_uc" in str(e):
             return jsonify({"message": "Já existe uma etapa com este nome."}), 409
        return jsonify({"message": "Erro ao criar etapa", "error": str(e)}), 500

# Update a pipeline stage (name or order)
@pipelines_bp.route("/stages/<int:stage_id>", methods=["PUT"])
@login_required
def update_pipeline_stage(stage_id):
    stage = PipelineStage.query.filter_by(id=stage_id, user_id=current_user.id).first()
    if not stage:
        return jsonify({"message": "Etapa não encontrada"}), 404

    data = request.get_json()
    updated = False

    if data.get("name") and data["name"] != stage.name:
        stage.name = data["name"]
        updated = True

    # TODO: Handle reordering logic if stage_order is changed. 
    # This requires shifting other stages, which is more complex.
    # For now, only updating name.
    # if data.get("order") is not None and data["order"] != stage.stage_order:
    #     stage.stage_order = data["order"]
    #     updated = True

    if updated:
        try:
            db.session.commit()
            return jsonify({
                "id": stage.id,
                "name": stage.name,
                "order": stage.stage_order
            })
        except Exception as e:
            db.session.rollback()
            if "_user_stage_name_uc" in str(e):
                 return jsonify({"message": "Já existe uma etapa com este nome."}), 409
            return jsonify({"message": "Erro ao atualizar etapa", "error": str(e)}), 500
    else:
        return jsonify({"message": "Nenhuma alteração fornecida"}), 400

# Delete a pipeline stage
@pipelines_bp.route("/stages/<int:stage_id>", methods=["DELETE"])
@login_required
def delete_pipeline_stage(stage_id):
    stage = PipelineStage.query.filter_by(id=stage_id, user_id=current_user.id).first()
    if not stage:
        return jsonify({"message": "Etapa não encontrada"}), 404

    # Optional: Check if leads are associated before deleting, or handle lead reassignment.
    # For now, leads associated will have pipeline_stage_id set to NULL due to ON DELETE SET NULL.

    try:
        db.session.delete(stage)
        # TODO: Re-order remaining stages if needed after deletion.
        db.session.commit()
        return jsonify({"message": "Etapa excluída com sucesso"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Erro ao excluir etapa", "error": str(e)}), 500

