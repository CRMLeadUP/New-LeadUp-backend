from src import db
from flask_login import UserMixin
from passlib.hash import pbkdf2_sha256 as sha256
from datetime import datetime

class User(db.Model, UserMixin):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String, unique=True, nullable=False)
    name = db.Column(db.String, nullable=False)
    password_hash = db.Column(db.String, nullable=False)
    plan = db.Column(db.String, nullable=False, default="free") # free, pro, advanced
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    # Relationships
    leads = db.relationship("Lead", backref="owner", lazy=True, cascade="all, delete-orphan")
    pipeline_stages = db.relationship("PipelineStage", backref="owner", lazy=True, cascade="all, delete-orphan")
    custom_field_definitions = db.relationship("CustomFieldDefinition", backref="owner", lazy=True, cascade="all, delete-orphan")
    user_plans = db.relationship("UserPlan", backref="owner", lazy=True, cascade="all, delete-orphan")
    api_keys = db.relationship("ApiKey", backref="owner", lazy=True, cascade="all, delete-orphan")

    def set_password(self, password):
        self.password_hash = sha256.hash(password)

    def check_password(self, password):
        return sha256.verify(password, self.password_hash)

    def __repr__(self):
        return f"<User {self.email}>"

