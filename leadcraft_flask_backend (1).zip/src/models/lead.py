from src import db
from datetime import datetime

class Lead(db.Model):
    __tablename__ = "leads"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    pipeline_stage_id = db.Column(db.Integer, db.ForeignKey("pipeline_stages.id", ondelete="SET NULL"), nullable=True)
    name = db.Column(db.String, nullable=False)
    email = db.Column(db.String)
    phone = db.Column(db.String)
    notes = db.Column(db.Text)
    lead_value = db.Column(db.Numeric(10, 2)) # Example standard field
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    custom_field_values = db.relationship("CustomFieldValue", backref="lead", lazy=True, cascade="all, delete-orphan")

    def __repr__(self):
        return f"<Lead {self.name} (User {self.user_id})>"

