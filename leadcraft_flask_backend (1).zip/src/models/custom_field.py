from src import db
from datetime import datetime

# Model for defining custom fields
class CustomFieldDefinition(db.Model):
    __tablename__ = "custom_field_definitions"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    field_name = db.Column(db.String, nullable=False)
    field_type = db.Column(db.String, nullable=False) # e.g., text, number, date, select
    options = db.Column(db.Text) # Comma-separated for select type
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    # Relationships
    values = db.relationship("CustomFieldValue", backref="definition", lazy=True, cascade="all, delete-orphan")

    # Constraints
    __table_args__ = (db.UniqueConstraint("user_id", "field_name", name="_user_field_name_uc"),)

    def __repr__(self):
        return f"<CustomFieldDefinition {self.field_name} (User {self.user_id})>"

# Model for storing values of custom fields for specific leads
class CustomFieldValue(db.Model):
    __tablename__ = "custom_field_values"

    id = db.Column(db.Integer, primary_key=True)
    lead_id = db.Column(db.Integer, db.ForeignKey("leads.id", ondelete="CASCADE"), nullable=False)
    custom_field_definition_id = db.Column(db.Integer, db.ForeignKey("custom_field_definitions.id", ondelete="CASCADE"), nullable=False)
    field_value = db.Column(db.Text) # Store all values as text, handle type conversion in application
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Constraints
    __table_args__ = (db.UniqueConstraint("lead_id", "custom_field_definition_id", name="_lead_field_uc"),)

    def __repr__(self):
        return f"<CustomFieldValue Lead {self.lead_id} Field {self.custom_field_definition_id}>"

