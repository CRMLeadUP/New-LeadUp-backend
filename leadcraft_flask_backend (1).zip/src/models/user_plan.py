from src import db
from datetime import datetime

class UserPlan(db.Model):
    __tablename__ = "user_plans"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    plan = db.Column(db.String, nullable=False, default="free") # free, pro, advanced
    active = db.Column(db.Boolean, nullable=False, default=True)
    # Could add subscription details like start_date, end_date, external_subscription_id
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __repr__(self):
        return f"<UserPlan User {self.user_id} - Plan {self.plan}>"

