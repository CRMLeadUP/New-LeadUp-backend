from src import db
from datetime import datetime
import secrets

class ApiKey(db.Model):
    __tablename__ = "api_keys"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    key = db.Column(db.String, unique=True, nullable=False, default=lambda: secrets.token_urlsafe(32))
    description = db.Column(db.String)
    is_active = db.Column(db.Boolean, nullable=False, default=True)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    def __repr__(self):
        return f"<ApiKey {self.key[:8]}... (User {self.user_id})>"

