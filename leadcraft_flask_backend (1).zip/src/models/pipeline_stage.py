from src import db
from datetime import datetime

class PipelineStage(db.Model):
    __tablename__ = "pipeline_stages"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    name = db.Column(db.String, nullable=False)
    stage_order = db.Column(db.Integer, nullable=False) # Order of the stage in the pipeline
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    # Relationships
    leads = db.relationship("Lead", backref="pipeline_stage", lazy=True)

    # Constraints
    __table_args__ = (db.UniqueConstraint("user_id", "name", name="_user_stage_name_uc"),
                      db.UniqueConstraint("user_id", "stage_order", name="_user_stage_order_uc"))

    def __repr__(self):
        return f"<PipelineStage {self.name} (User {self.user_id})>"

