# Entry point for deployment
import os
from src import create_app

app = create_app()

# The deployment environment will run this using a production WSGI server (like Gunicorn)
# No need for app.run() here for deployment

